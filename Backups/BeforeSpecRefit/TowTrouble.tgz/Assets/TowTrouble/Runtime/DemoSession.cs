using System.Collections;
using FishNet.Managing;
using FishNet.Transporting;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

namespace TowTrouble
{
    public sealed class DemoSession : MonoBehaviour
    {
        [SerializeField] private NetworkManager network;
        [SerializeField] private RecoveryWorld world;
        [SerializeField] private RecoveryCamera recoveryCamera;
        private float nextInput;
        private float connectDeadline;
        private bool quickStart;
        private bool readySent;
        private bool leaving;
        private bool wasConnected;
        private bool menuOpen;
        private string status = "A small crew. A heavy pull.";
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        internal bool ValidationInputActive;
        internal Vector2 ValidationInput;
        internal bool ValidationBrake, ValidationWinch;
#endif

        public RecoveryWorld World => world;
        public NetworkManager Network => network;
        public bool Connected => network != null && network.ClientManager != null && world != null && world.NetworkObject != null && network.ClientManager.Started && world.IsClientInitialized;
        public bool Connecting { get; private set; }
        public bool IsHost => network != null && network.ServerManager != null && network.ServerManager.Started;
        public int LocalSlot => Connected ? world.Slot(network.ClientManager.Connection.ClientId) : -1;
        public bool MenuOpen => menuOpen;
        public string Status => status;

        public void Configure(NetworkManager manager, RecoveryWorld recoveryWorld, RecoveryCamera cameraRig)
        { network = manager; world = recoveryWorld; recoveryCamera = cameraRig; }

        private void Start()
        {
            Application.targetFrameRate = 60;
            network.ServerManager.SetFrameRate(60);
            network.ClientManager.SetFrameRate(60);
            network.ClientManager.OnClientConnectionState += ClientState;
            recoveryCamera.Bind(this);
            var args = System.Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "-tow-host") Host(false);
                if (args[i] == "-tow-solo") Host(true);
                if (args[i] == "-tow-join" && i + 1 < args.Length) Join(args[++i]);
            }
        }

        private void OnDestroy()
        {
            if (network != null && network.ClientManager != null) network.ClientManager.OnClientConnectionState -= ClientState;
        }

        private void ClientState(ClientConnectionStateArgs args)
        {
            if (args.ConnectionState == LocalConnectionState.Started)
            { Connecting = false; wasConnected = true; status = "Connected. Get your crew ready."; }
            else if (args.ConnectionState == LocalConnectionState.Stopped && !leaving)
            {
                Connecting = false;
                status = wasConnected ? "Connection closed. Return to the menu to reconnect." : "Could not connect. Check the host address and UDP port 7777.";
                if (IsHost) network.ServerManager.StopConnection(true);
            }
        }

        public void Host(bool solo)
        {
            if (Connecting || Connected || leaving) return;
            quickStart = solo; readySent = false; Connecting = true; connectDeadline = Time.unscaledTime + 12f;
            status = "Starting FishNet host...";
            network.TransportManager.Transport.SetMaximumClients(2);
            network.TransportManager.Transport.SetPort(7777);
            network.TransportManager.Transport.SetClientAddress("127.0.0.1");
            if (!network.ServerManager.StartConnection()) { Connecting = false; status = "Port 7777 is unavailable."; return; }
            network.ClientManager.StartConnection();
        }

        public void Join(string address)
        {
            if (Connecting || Connected || leaving) return;
            address = address.Trim();
            if (address.Length == 0 || address.Length > 253) { status = "Enter a valid host address."; return; }
            quickStart = false; readySent = false; Connecting = true; connectDeadline = Time.unscaledTime + 12f;
            status = "Connecting to crew...";
            network.TransportManager.Transport.SetPort(7777);
            network.TransportManager.Transport.SetClientAddress(address);
            network.ClientManager.StartConnection();
        }

        public void ToggleReady()
        {
            if (Connected && LocalSlot >= 0) world.SetReady(!world.Ready(LocalSlot));
        }

        public void Deploy() { if (Connected && IsHost) world.StartRecovery(); }
        public void Replay() { if (Connected && IsHost) { menuOpen = false; world.ReturnToLobby(); } }
        public void ToggleMenu() { menuOpen = !menuOpen; }

        public void Leave()
        {
            if (leaving) return;
            leaving = true; network.ClientManager.StopConnection();
            if (IsHost) network.ServerManager.StopConnection(true);
            StartCoroutine(Reload());
        }

        private IEnumerator Reload()
        {
            yield return new WaitForSecondsRealtime(.25f);
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        private void Update()
        {
            if (Connecting && Time.unscaledTime > connectDeadline)
            {
                Connecting = false; network.ClientManager.StopConnection();
                if (IsHost) network.ServerManager.StopConnection(true);
                status = "Connection timed out. Check the address and host firewall.";
            }
            if (!Connected || LocalSlot < 0) return;
            if (quickStart && world.Phase == RecoveryPhase.Lobby)
            {
                if (!readySent) { readySent = true; world.SetReady(true); }
                if (world.CanStart) { quickStart = false; world.StartRecovery(); }
            }
            var keyboard = Keyboard.current;
            var pad = Gamepad.current;
            if ((keyboard != null && keyboard.escapeKey.wasPressedThisFrame) || (pad != null && pad.startButton.wasPressedThisFrame)) ToggleMenu();
            if (world.Phase == RecoveryPhase.Lobby || world.Phase == RecoveryPhase.Complete) return;
            if (!menuOpen)
            {
                if ((keyboard != null && keyboard.eKey.wasPressedThisFrame) || (pad != null && pad.buttonSouth.wasPressedThisFrame)) world.ToggleCable();
                if ((keyboard != null && keyboard.rKey.wasPressedThisFrame) || (pad != null && pad.selectButton.wasPressedThisFrame)) world.Unstuck();
            }
            if (Time.unscaledTime < nextInput) return;
            nextInput = Time.unscaledTime + .05f;
#if UNITY_EDITOR || DEVELOPMENT_BUILD
            if (ValidationInputActive)
            {
                world.Drive(ValidationInput, ValidationBrake, ValidationWinch);
                return;
            }
#endif
            Vector2 input = Vector2.zero; bool brake = menuOpen; bool winch = false;
            if (!menuOpen)
            {
                if (keyboard != null)
                {
                    input.x = (keyboard.dKey.isPressed || keyboard.rightArrowKey.isPressed ? 1f : 0f) - (keyboard.aKey.isPressed || keyboard.leftArrowKey.isPressed ? 1f : 0f);
                    input.y = (keyboard.wKey.isPressed || keyboard.upArrowKey.isPressed ? 1f : 0f) - (keyboard.sKey.isPressed || keyboard.downArrowKey.isPressed ? 1f : 0f);
                    brake = keyboard.spaceKey.isPressed; winch = keyboard.qKey.isPressed;
                }
                if (pad != null && (pad.leftStick.ReadValue().sqrMagnitude > .05f || pad.rightTrigger.ReadValue() > .05f || pad.leftTrigger.ReadValue() > .05f))
                {
                    input.x = pad.leftStick.x.ReadValue(); input.y = pad.rightTrigger.ReadValue() - pad.leftTrigger.ReadValue();
                    brake = pad.buttonEast.isPressed; winch = pad.leftShoulder.isPressed;
                }
            }
            world.Drive(input, brake, winch);
        }
    }
}
