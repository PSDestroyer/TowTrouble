using FishNet.Connection;
using FishNet.Object;
using FishNet.Object.Synchronizing;
using FishNet.Transporting;
using UnityEngine;

namespace TowTrouble
{
    public struct VehicleFrame
    {
        public Vector3 Position;
        public Quaternion Rotation;
        public float Speed;
        public VehicleFrame(RecoveryVehicle vehicle) { Position = vehicle.transform.position; Rotation = vehicle.transform.rotation; Speed = vehicle.Speed; }
    }

    public struct RecoveryFrame
    {
        public VehicleFrame Driver0, Driver1, Casualty;
        public bool Cable0, Cable1;
        public float Tension0, Tension1, Elapsed;
        public int Snaps;
    }

    public sealed class RecoveryWorld : NetworkBehaviour
    {
        [SerializeField] private RecoveryVehicle[] drivers;
        [SerializeField] private RecoveryVehicle casualty;
        [SerializeField] private LineRenderer[] cables;
        private readonly SyncVar<int> phase = new SyncVar<int>();
        private readonly SyncVar<int> driver0Id = new SyncVar<int>(-1);
        private readonly SyncVar<int> driver1Id = new SyncVar<int>(-1);
        private readonly SyncVar<bool> ready0 = new SyncVar<bool>();
        private readonly SyncVar<bool> ready1 = new SyncVar<bool>();
        private readonly bool[] connected = new bool[2];
        private readonly bool[] winching = new bool[2];
        private readonly float[] lengths = new float[2];
        private readonly float[] tensions = new float[2];
        private readonly float[] overload = new float[2];
        private readonly float[] lastInput = new float[2];
        private readonly float[] lastAction = new float[2];
        private float nextSnapshot;
        private float elapsed;
        private int snaps;
        private float deliveryHold;

        public RecoveryPhase Phase => (RecoveryPhase)phase.Value;
        public RecoveryVehicle[] Drivers => drivers;
        public RecoveryVehicle Casualty => casualty;
        public float Elapsed => elapsed;
        public int Snaps => snaps;
        public int Occupied => (driver0Id.Value >= 0 ? 1 : 0) + (driver1Id.Value >= 0 ? 1 : 0);
        public bool CanStart => Occupied > 0 && ready0.Value && (driver1Id.Value < 0 || ready1.Value);
        public int Slot(int id) => id == driver0Id.Value && id >= 0 ? 0 : (id == driver1Id.Value && id >= 0 ? 1 : -1);
        public bool Ready(int slot) => slot == 0 ? ready0.Value : ready1.Value;
        public bool OccupiedSlot(int slot) => (slot == 0 ? driver0Id.Value : driver1Id.Value) >= 0;
        public bool Attached(int slot) => slot >= 0 && connected[slot];
        public float Tension(int slot) => slot < 0 ? 0f : tensions[slot];

        public void Configure(RecoveryVehicle[] vehicles, RecoveryVehicle target, LineRenderer[] lines)
        { drivers = vehicles; casualty = target; cables = lines; }

        public override void OnStartServer()
        {
            base.OnStartServer();
            NetworkManager.SceneManager.OnClientLoadedStartScenes += ClientLoaded;
            NetworkManager.ServerManager.OnRemoteConnectionState += RemoteChanged;
            phase.Value = 0; driver0Id.Value = -1; driver1Id.Value = -1;
            ResetRecovery();
        }

        public override void OnStopServer()
        {
            NetworkManager.SceneManager.OnClientLoadedStartScenes -= ClientLoaded;
            NetworkManager.ServerManager.OnRemoteConnectionState -= RemoteChanged;
            base.OnStopServer();
        }

        private void ClientLoaded(NetworkConnection connection, bool asServer)
        {
            if (!asServer || Slot(connection.ClientId) >= 0) return;
            // Reserve driver 01 for the host even when a remote peer finishes loading first.
            if (connection.IsLocalClient)
            {
                if (driver0Id.Value >= 0) { connection.Disconnect(true); return; }
                driver0Id.Value = connection.ClientId;
            }
            else
            {
                if (driver1Id.Value >= 0) { connection.Disconnect(true); return; }
                driver1Id.Value = connection.ClientId;
            }
            NetworkManager.SceneManager.AddConnectionToScene(connection, gameObject.scene);
        }

        private void RemoteChanged(NetworkConnection connection, RemoteConnectionStateArgs args)
        {
            if (args.ConnectionState != RemoteConnectionState.Stopped) return;
            int slot = Slot(connection.ClientId);
            if (slot < 0) return;
            drivers[slot].SetInput(Vector2.zero, true); connected[slot] = false; winching[slot] = false;
            if (slot == 0) { driver0Id.Value = -1; ready0.Value = false; }
            else { driver1Id.Value = -1; ready1.Value = false; }
        }

        [ServerRpc(RequireOwnership = false)]
        public void SetReady(bool value, NetworkConnection sender = null)
        {
            int slot = sender == null ? -1 : Slot(sender.ClientId);
            if (slot == 0) ready0.Value = value;
            else if (slot == 1) ready1.Value = value;
        }

        [ServerRpc(RequireOwnership = false)]
        public void StartRecovery(NetworkConnection sender = null)
        {
            if (sender == null || Slot(sender.ClientId) != 0 || !CanStart || Phase != RecoveryPhase.Lobby) return;
            ResetRecovery(); phase.Value = (int)RecoveryPhase.HookUp;
            foreach (var car in drivers) car.SetSimulation(true);
            casualty.SetSimulation(true);
        }

        [ServerRpc(RequireOwnership = false)]
        public void ReturnToLobby(NetworkConnection sender = null)
        {
            if (sender == null || Slot(sender.ClientId) != 0) return;
            phase.Value = 0; ready0.Value = false; ready1.Value = false; ResetRecovery();
        }

        [ServerRpc(RequireOwnership = false)]
        public void Drive(Vector2 input, bool brake, bool winch, NetworkConnection sender = null)
        {
            int slot = sender == null ? -1 : Slot(sender.ClientId);
            if (slot < 0 || Phase == RecoveryPhase.Lobby || Phase == RecoveryPhase.Complete) return;
            if (!float.IsFinite(input.x) || !float.IsFinite(input.y)) return;
            drivers[slot].SetInput(Vector2.ClampMagnitude(input, 1f), brake);
            winching[slot] = winch; lastInput[slot] = Time.time;
        }

        [ServerRpc(RequireOwnership = false)]
        public void ToggleCable(NetworkConnection sender = null)
        {
            int slot = sender == null ? -1 : Slot(sender.ClientId);
            if (slot < 0 || Phase == RecoveryPhase.Lobby || Phase == RecoveryPhase.Complete || Time.time - lastAction[slot] < .35f) return;
            lastAction[slot] = Time.time;
            if (connected[slot]) { connected[slot] = false; tensions[slot] = 0; return; }
            float distance = Vector3.Distance(drivers[slot].RearHitch, casualty.FrontHitch);
            if (distance > RecoveryRules.AttachRange) return;
            connected[slot] = true; lengths[slot] = Mathf.Max(3.5f, distance - .3f); overload[slot] = 0f;
            if (Phase == RecoveryPhase.HookUp) phase.Value = (int)RecoveryPhase.Recover;
        }

        [ServerRpc(RequireOwnership = false)]
        public void Unstuck(NetworkConnection sender = null)
        {
            int slot = sender == null ? -1 : Slot(sender.ClientId);
            if (slot < 0 || Phase == RecoveryPhase.Lobby || Phase == RecoveryPhase.Complete || Time.time - lastAction[slot] < 2f) return;
            lastAction[slot] = Time.time; connected[slot] = false; drivers[slot].ResetVehicle(false);
        }

        private void ResetRecovery()
        {
            elapsed = 0; snaps = 0; deliveryHold = 0;
            for (int i = 0; i < 2; i++)
            {
                connected[i] = false; tensions[i] = 0; winching[i] = false; lastInput[i] = Time.time;
                drivers[i].ResetVehicle(true); drivers[i].SetSimulation(false);
            }
            casualty.ResetVehicle(true); casualty.SetSimulation(false);
        }

        private void FixedUpdate()
        {
            if (!IsServerInitialized || Phase == RecoveryPhase.Lobby || Phase == RecoveryPhase.Complete) return;
            elapsed += Time.fixedDeltaTime;
            for (int i = 0; i < 2; i++)
            {
                if (Time.time - lastInput[i] > .6f) { drivers[i].SetInput(Vector2.zero, true); winching[i] = false; }
                if (!connected[i]) { tensions[i] = 0; continue; }
                var a = drivers[i].RearHitch; var b = casualty.FrontHitch;
                var delta = a - b; float distance = delta.magnitude;
                var direction = distance > .01f ? delta / distance : Vector3.forward;
                if (winching[i]) lengths[i] = Mathf.Max(3.5f, lengths[i] - Time.fixedDeltaTime * 1.3f);
                float speed = Vector3.Dot(drivers[i].Body.GetPointVelocity(a) - casualty.Body.GetPointVelocity(b), direction);
                float force = RecoveryRules.CableForce(distance, lengths[i], speed);
                tensions[i] = Mathf.Clamp01(force / RecoveryRules.BreakForce);
                overload[i] = force > RecoveryRules.BreakForce ? overload[i] + Time.fixedDeltaTime : Mathf.Max(0, overload[i] - Time.fixedDeltaTime * 2f);
                if (overload[i] > .55f || distance > 25f)
                { connected[i] = false; tensions[i] = 0; snaps++; continue; }
                casualty.Body.AddForceAtPosition(direction * force, b);
                drivers[i].Body.AddForceAtPosition(-direction * force, a);
            }
            if (Phase == RecoveryPhase.Recover && casualty.transform.position.z >= RecoveryRules.ExtractionZ)
                phase.Value = (int)RecoveryPhase.Deliver;
            if (Phase == RecoveryPhase.Deliver)
            {
                deliveryHold = RecoveryRules.Delivered(casualty.transform.position, casualty.Speed) ? deliveryHold + Time.fixedDeltaTime : 0;
                if (deliveryHold > 1.2f)
                {
                    phase.Value = (int)RecoveryPhase.Complete;
                    foreach (var car in drivers) car.SetInput(Vector2.zero, true);
                    casualty.SetInput(Vector2.zero, true);
                }
            }
        }

        private void Update()
        {
            if (IsServerInitialized && Time.unscaledTime >= nextSnapshot)
            {
                nextSnapshot = Time.unscaledTime + 1f / 15f;
                Snapshot(new RecoveryFrame { Driver0 = new VehicleFrame(drivers[0]), Driver1 = new VehicleFrame(drivers[1]), Casualty = new VehicleFrame(casualty),
                    Cable0 = connected[0], Cable1 = connected[1], Tension0 = tensions[0], Tension1 = tensions[1], Elapsed = elapsed, Snaps = snaps });
            }
        }

        [ObserversRpc(BufferLast = true)]
        private void Snapshot(RecoveryFrame frame, Channel channel = Channel.Unreliable)
        {
            if (IsServerInitialized) return;
            drivers[0].Receive(frame.Driver0.Position, frame.Driver0.Rotation, frame.Driver0.Speed);
            drivers[1].Receive(frame.Driver1.Position, frame.Driver1.Rotation, frame.Driver1.Speed);
            casualty.Receive(frame.Casualty.Position, frame.Casualty.Rotation, frame.Casualty.Speed);
            connected[0] = frame.Cable0; connected[1] = frame.Cable1;
            tensions[0] = frame.Tension0; tensions[1] = frame.Tension1; elapsed = frame.Elapsed; snaps = frame.Snaps;
        }

        private void LateUpdate()
        {
            for (int i = 0; i < 2; i++)
            {
                cables[i].enabled = connected[i];
                if (!connected[i]) continue;
                var a = drivers[i].RearHitch; var b = casualty.FrontHitch;
                float sag = Mathf.Lerp(.5f, .03f, tensions[i]);
                for (int j = 0; j < cables[i].positionCount; j++)
                {
                    float t = j / (float)(cables[i].positionCount - 1);
                    cables[i].SetPosition(j, Vector3.Lerp(a, b, t) - Vector3.up * (4f * t * (1f - t) * sag));
                }
                cables[i].startColor = cables[i].endColor = Color.Lerp(new Color(.12f, .15f, .18f), new Color(1f, .35f, .08f), Mathf.InverseLerp(.65f, 1f, tensions[i]));
            }
        }
    }
}
