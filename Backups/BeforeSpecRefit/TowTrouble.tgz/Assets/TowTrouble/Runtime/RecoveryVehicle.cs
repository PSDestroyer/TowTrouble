using UnityEngine;

namespace TowTrouble
{
    [RequireComponent(typeof(Rigidbody))]
    public sealed class RecoveryVehicle : MonoBehaviour
    {
        [SerializeField] private WheelCollider[] wheels;
        [SerializeField] private Transform[] wheelVisuals;
        [SerializeField] private Transform frontHitch;
        [SerializeField] private Transform rearHitch;
        [SerializeField] private bool casualty;
        private Rigidbody body;
        private bool simulate;
        private Vector2 input;
        private bool brake;
        private Vector3 startPosition;
        private Quaternion startRotation;
        private Vector3 remotePosition;
        private Quaternion remoteRotation;
        private float remoteSpeed;
        private bool hasRemote;
        private AudioSource engine;
        private ParticleSystem dust;
        private Vector3[] suspensionPositions;
        private float wheelSpin;

        public Rigidbody Body => body;
        public Vector3 FrontHitch => frontHitch.position;
        public Vector3 RearHitch => rearHitch.position;
        public float Speed => simulate ? body.linearVelocity.magnitude : remoteSpeed;
        public bool InMud => casualty && transform.position.z < 27f;

        public void Configure(WheelCollider[] colliders, Transform[] visuals, Transform front, Transform rear, bool isCasualty)
        {
            wheels = colliders; wheelVisuals = visuals; frontHitch = front; rearHitch = rear; casualty = isCasualty;
        }

        private void Awake()
        {
            body = GetComponent<Rigidbody>();
            body.centerOfMass = new Vector3(0f, .45f, 0f);
            body.sleepThreshold = 0f;
            startPosition = transform.position; startRotation = transform.rotation;
            remotePosition = startPosition; remoteRotation = startRotation;
            engine = GetComponent<AudioSource>();
            dust = GetComponentInChildren<ParticleSystem>();
            suspensionPositions = new Vector3[wheels.Length];
            for (int i = 0; i < wheels.Length; i++) suspensionPositions[i] = wheelVisuals[i].position;
            SetSimulation(false);
        }

        public void SetSimulation(bool value)
        {
            if (body == null) body = GetComponent<Rigidbody>();
            simulate = value;
            body.interpolation = value ? RigidbodyInterpolation.Interpolate : RigidbodyInterpolation.None;
            body.isKinematic = !value;
            // WheelCollider assets supply the authored suspension geometry. Contact forces
            // are integrated here so towing, brakes and mud share one server simulation.
            foreach (var w in wheels) w.enabled = false;
            if (value) body.WakeUp();
            if (!value) input = Vector2.zero;
        }

        public void SetInput(Vector2 value, bool handbrake)
        {
            input = Vector2.ClampMagnitude(value, 1f); brake = handbrake;
            if (simulate && input.sqrMagnitude > .01f) body.WakeUp();
        }

        public void ResetVehicle(bool original)
        {
            var p = original ? startPosition : transform.position + Vector3.up * 1.2f;
            var r = original ? startRotation : Quaternion.Euler(0f, transform.eulerAngles.y, 0f);
            body.position = p; body.rotation = r;
            if (!body.isKinematic) { body.linearVelocity = Vector3.zero; body.angularVelocity = Vector3.zero; }
            transform.SetPositionAndRotation(p, r); input = Vector2.zero; hasRemote = false;
        }

        public void Receive(Vector3 position, Quaternion rotation, float speed)
        {
            remotePosition = position; remoteRotation = rotation; remoteSpeed = speed; hasRemote = true;
            if (Vector3.Distance(transform.position, position) > 12f) transform.SetPositionAndRotation(position, rotation);
        }

        private void FixedUpdate()
        {
            if (!simulate) return;
            float forwardSpeed = Vector3.Dot(body.linearVelocity, transform.forward);
            float steer = input.x * Mathf.Lerp(30f, 15f, Mathf.Abs(forwardSpeed) / 14f);
            bool grounded = false;
            for (int i = 0; i < wheels.Length; i++)
            {
                var w = wheels[i];
                var up = transform.up;
                var origin = w.transform.position + up * .3f;
                float reach = w.radius + w.suspensionDistance + .3f;
                if (!Physics.Raycast(origin, -up, out var hit, reach, 1 << 8, QueryTriggerInteraction.Ignore))
                { suspensionPositions[i] = w.transform.position - up * w.suspensionDistance; continue; }
                grounded = true;
                var pointVelocity = body.GetPointVelocity(w.transform.position);
                float compression = Mathf.Clamp(reach - hit.distance, 0f, w.suspensionDistance);
                float support = Mathf.Clamp(compression * 37000f - Vector3.Dot(pointVelocity, up) * 4500f, 0f, 18000f);
                body.AddForceAtPosition(up * support, w.transform.position);
                var forward = Vector3.ProjectOnPlane(Quaternion.AngleAxis(i < 2 ? steer : 0f, up) * transform.forward, hit.normal).normalized;
                var right = Vector3.Cross(hit.normal, forward).normalized;
                float longitudinal = Vector3.Dot(pointVelocity, forward);
                float lateral = Vector3.Dot(pointVelocity, right);
                float drive = casualty ? 0f : input.y * 3100f * Mathf.Clamp01((13f - Mathf.Abs(forwardSpeed)) / 3f);
                float rolling = casualty ? 100f : Mathf.Abs(input.y) < .05f ? 240f : 35f;
                float braking = Mathf.Clamp(-longitudinal * (brake ? 1300f : rolling), -5500f, 5500f);
                var tireForce = forward * (drive + braking) + right * Mathf.Clamp(-lateral * 1400f, -5000f, 5000f);
                body.AddForceAtPosition(tireForce, hit.point);
                suspensionPositions[i] = hit.point + hit.normal * w.radius;
            }
            if (grounded)
            {
                body.AddForce(-transform.up * body.linearVelocity.magnitude * 70f);
            }
            if (InMud) body.AddForce(-body.linearVelocity * 1700f);
            if (transform.position.y < -10f) ResetVehicle(true);
        }

        private void LateUpdate()
        {
            if (!simulate && hasRemote)
            {
                float blend = 1f - Mathf.Exp(-14f * Time.deltaTime);
                transform.SetPositionAndRotation(Vector3.Lerp(transform.position, remotePosition, blend), Quaternion.Slerp(transform.rotation, remoteRotation, blend));
            }
            wheelSpin += (simulate ? Vector3.Dot(body.linearVelocity, transform.forward) : remoteSpeed) * Time.deltaTime * Mathf.Rad2Deg / .47f;
            for (int i = 0; i < wheels.Length; i++)
            {
                if (simulate)
                {
                    var q = transform.rotation * Quaternion.Euler(wheelSpin, i < 2 ? input.x * 30f : 0f, 0f);
                    wheelVisuals[i].SetPositionAndRotation(suspensionPositions[i], q);
                }
                else wheelVisuals[i].localRotation = Quaternion.Euler(wheelSpin, 0f, 0f);
            }
            if (engine != null)
            {
                engine.pitch = .6f + Speed * .09f;
                engine.volume = casualty ? 0f : .09f + Mathf.Abs(input.y) * .08f;
            }
            if (dust != null)
            {
                var emission = dust.emission;
                emission.rateOverTime = Speed > 1f ? Mathf.Min(Speed * 2f, 22f) : 0f;
            }
        }
    }
}
