using UnityEngine;
using UnityEngine.InputSystem;

namespace TowTrouble
{
    public sealed class RecoveryCamera : MonoBehaviour
    {
        private DemoSession session;
        private Vector3 velocity;
        private float orbit;
        public void Bind(DemoSession owner) { session = owner; }

        private void LateUpdate()
        {
            if (session == null) return;
            bool lobby = !session.Connected || session.World.Phase == RecoveryPhase.Lobby;
            Vector3 position; Vector3 look;
            if (lobby)
            {
                position = new Vector3(15f, 8.7f, 39f);
                look = new Vector3(-1f, 1.1f, 22f);
            }
            else
            {
                int slot = Mathf.Max(0, session.LocalSlot);
                var car = session.World.Drivers[slot].transform;
                if (Mouse.current != null && Mouse.current.rightButton.isPressed && !session.MenuOpen)
                    orbit += Mouse.current.delta.x.ReadValue() * .12f;
                else orbit = Mathf.Lerp(orbit, 0f, Time.deltaTime * 2.5f);
                var rotation = Quaternion.Euler(0f, car.eulerAngles.y + orbit, 0f);
                var target = session.World.Casualty.transform.position;
                var center = Vector3.Distance(car.position, target) < 28f ? Vector3.Lerp(car.position, target, .4f) : car.position;
                position = center + rotation * new Vector3(0f, 8f, -15f);
                look = center + Vector3.up * 1.2f + car.forward;
                if (Physics.Linecast(look, position, out var hit, 1 << 8)) position = hit.point + hit.normal * .5f;
            }
            transform.position = Vector3.SmoothDamp(transform.position, position, ref velocity, .24f, Mathf.Infinity, Time.unscaledDeltaTime);
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(look - transform.position), 1f - Mathf.Exp(-7f * Time.unscaledDeltaTime));
        }
    }
}
