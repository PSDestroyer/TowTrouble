using TMPro;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem.UI;

namespace TowTrouble
{
    public sealed class RecoveryHud : MonoBehaviour
    {
        [SerializeField] private DemoSession session;
        [SerializeField] private TMP_FontAsset font;
        private RectTransform root;
        private GameObject menu, lobby, hud, finish, pause;
        private TMP_Text status, connection, driver0, driver1, readyLabel, objective, crew, speed, tensionLabel, hint, distance, result, marker;
        private UnityEngine.UI.Image tension;
        private UnityEngine.UI.Button readyButton, deployButton, returnLobbyButton;
        private TMP_InputField address;
        private float nextRefresh;
        private static readonly Color Ink = new Color(.065f, .1f, .12f, .94f);
        private static readonly Color Paper = new Color(.98f, .94f, .82f);
        private static readonly Color Amber = new Color(1f, .69f, .22f);
        private static readonly Color Muted = new Color(.61f, .72f, .71f);
        public void Configure(DemoSession owner, TMP_FontAsset asset) { session = owner; font = asset; }

        private void Awake()
        {
            if (EventSystem.current == null)
                new GameObject("UI Event System", typeof(EventSystem), typeof(InputSystemUIInputModule));
            var canvas = new GameObject("Tow Trouble UI", typeof(RectTransform), typeof(Canvas), typeof(UnityEngine.UI.CanvasScaler), typeof(UnityEngine.UI.GraphicRaycaster));
            canvas.transform.SetParent(transform, false);
            canvas.GetComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvas.GetComponent<UnityEngine.UI.CanvasScaler>();
            scaler.uiScaleMode = UnityEngine.UI.CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1600, 900); scaler.matchWidthOrHeight = .5f;
            root = canvas.GetComponent<RectTransform>();
            BuildMenu(); BuildLobby(); BuildHud(); BuildFinish(); BuildPause();
        }

        private RectTransform Rect(string name, Transform parent, Vector2 min, Vector2 max, Vector2 offsetMin, Vector2 offsetMax)
        {
            var go = new GameObject(name, typeof(RectTransform)); go.transform.SetParent(parent, false);
            var rt = go.GetComponent<RectTransform>(); rt.anchorMin = min; rt.anchorMax = max; rt.offsetMin = offsetMin; rt.offsetMax = offsetMax; return rt;
        }

        private RectTransform Box(string name, Transform parent, float x, float y, float w, float h, Color color)
        {
            var rt = Rect(name, parent, new Vector2(0, 1), new Vector2(0, 1), Vector2.zero, Vector2.zero);
            rt.pivot = new Vector2(0, 1); rt.anchoredPosition = new Vector2(x, -y); rt.sizeDelta = new Vector2(w, h);
            var image = rt.gameObject.AddComponent<UnityEngine.UI.Image>(); image.color = color; image.raycastTarget = false; return rt;
        }

        private TMP_Text Text(Transform parent, string value, float x, float y, float w, float h, float size, Color color, FontStyles style = FontStyles.Normal)
        {
            var rt = Rect("Text", parent, new Vector2(0, 1), new Vector2(0, 1), Vector2.zero, Vector2.zero);
            rt.pivot = new Vector2(0, 1); rt.anchoredPosition = new Vector2(x, -y); rt.sizeDelta = new Vector2(w, h);
            var t = rt.gameObject.AddComponent<TextMeshProUGUI>(); t.font = font; t.text = value; t.fontSize = size; t.color = color;
            t.fontStyle = style; t.textWrappingMode = TextWrappingModes.Normal; t.raycastTarget = false; return t;
        }

        private UnityEngine.UI.Button Button(Transform parent, string label, float x, float y, float w, System.Action action, bool primary = false)
        {
            var rt = Box(label, parent, x, y, w, 54, primary ? Amber : new Color(.17f, .24f, .26f));
            rt.GetComponent<UnityEngine.UI.Image>().raycastTarget = true;
            var button = rt.gameObject.AddComponent<UnityEngine.UI.Button>();
            button.targetGraphic = rt.GetComponent<UnityEngine.UI.Image>();
            var colors = button.colors; colors.highlightedColor = new Color(1f, .92f, .72f); colors.pressedColor = new Color(.8f, .8f, .8f); button.colors = colors;
            var t = Text(rt, label, 18, 13, w - 36, 32, 19, primary ? Ink : Paper, FontStyles.Bold);
            t.alignment = TextAlignmentOptions.Center; button.onClick.AddListener(() => action()); return button;
        }

        private RectTransform Screen(string name)
        {
            var rt = Rect(name, root, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero); return rt;
        }

        private RectTransform Card(Transform parent, string name, float width, float height)
        {
            var rt = Rect(name, parent, new Vector2(.04f, .5f), new Vector2(.04f, .5f), Vector2.zero, Vector2.zero);
            rt.pivot = new Vector2(0, .5f); rt.sizeDelta = new Vector2(width, height);
            rt.gameObject.AddComponent<UnityEngine.UI.Image>().color = Ink;
            Box("Accent", rt, 0, 0, 5, height, Amber); return rt;
        }

        private void BuildMenu()
        {
            menu = Screen("Main Menu").gameObject;
            var panel = Card(menu.transform, "Dispatch", 500, 720);
            Text(panel, "CANYON COUNTY  /  RECOVERY CLUB", 36, 32, 430, 26, 14, Amber, FontStyles.Bold);
            Text(panel, "TOW\nTROUBLE", 30, 74, 440, 190, 78, Paper, FontStyles.Bold);
            Text(panel, "GOOD COMPANY. BAD ROADS.", 36, 268, 430, 28, 17, Muted, FontStyles.Bold);
            Box("Rule", panel, 36, 316, 428, 1, new Color(.32f, .41f, .4f));
            Text(panel, "01  /  MUDDY BUSINESS", 36, 338, 430, 30, 22, Paper, FontStyles.Bold);
            Text(panel, "A stranded classic. One stubborn mud pit.\nHook up, pull together and bring it home.", 36, 378, 430, 65, 18, Muted);
            Button(panel, "SOLO RECOVERY   >", 36, 466, 428, () => session.Host(true), true);
            Button(panel, "HOST CO-OP", 36, 534, 204, () => session.Host(false));
            Button(panel, "JOIN CREW", 252, 534, 212, () => session.Join(address.text));
            var field = Box("Host address", panel, 36, 604, 428, 44, new Color(.035f, .065f, .075f));
            field.GetComponent<UnityEngine.UI.Image>().raycastTarget = true;
            address = field.gameObject.AddComponent<TMP_InputField>();
            var viewport = Rect("Viewport", field, Vector2.zero, Vector2.one, new Vector2(12, 3), new Vector2(-12, -3));
            var value = Text(viewport, "", 0, 0, 400, 38, 18, Paper); value.alignment = TextAlignmentOptions.MidlineLeft;
            address.textViewport = viewport; address.textComponent = (TextMeshProUGUI)value; address.text = "127.0.0.1"; address.characterLimit = 253;
            status = Text(panel, "", 36, 664, 430, 46, 14, Muted);
            var badge = Rect("Demo badge", menu.transform, Vector2.one, Vector2.one, new Vector2(-390, -72), new Vector2(-36, -30));
            Text(badge, "FIRST FIELD TEST  /  DEMO 0.1", 0, 0, 354, 30, 16, Paper, FontStyles.Bold).alignment = TextAlignmentOptions.Right;
            Text(menu.transform, "DRIVE TOGETHER. GET HOME TOGETHER.", 610, 792, 900, 40, 18, Paper, FontStyles.Bold);
        }

        private void BuildLobby()
        {
            lobby = Screen("Crew Lobby").gameObject;
            var panel = Card(lobby.transform, "Crew manifest", 520, 660);
            Text(panel, "DISPATCH  /  CREW MANIFEST", 36, 30, 448, 30, 15, Amber, FontStyles.Bold);
            Text(panel, "LET'S GET\nYOU ROLLING.", 32, 82, 460, 140, 47, Paper, FontStyles.Bold);
            connection = Text(panel, "", 36, 228, 448, 56, 15, Muted);
            Box("Driver 01", panel, 36, 300, 448, 60, new Color(.16f, .23f, .25f));
            Box("Driver 02", panel, 36, 372, 448, 60, new Color(.16f, .23f, .25f));
            driver0 = Text(panel, "", 54, 319, 410, 30, 19, Paper, FontStyles.Bold);
            driver1 = Text(panel, "", 54, 391, 410, 30, 19, Paper, FontStyles.Bold);
            readyButton = Button(panel, "READY UP", 36, 458, 210, () => session.ToggleReady());
            readyLabel = readyButton.GetComponentInChildren<TMP_Text>();
            deployButton = Button(panel, "START MISSION  >", 258, 458, 226, () => session.Deploy(), true);
            Text(panel, "MUDDY BUSINESS  /  1-2 DRIVERS\nRecover the red car. Deliver to the workshop.", 36, 536, 448, 60, 17, Muted);
            Button(panel, "BACK", 36, 606, 448, () => session.Leave());
        }

        private void BuildHud()
        {
            hud = Screen("Mission HUD").gameObject;
            var top = Box("Mission", hud.transform, 30, 26, 440, 125, Ink);
            Text(top, "01  /  MUDDY BUSINESS", 20, 14, 400, 25, 14, Amber, FontStyles.Bold);
            objective = Text(top, "", 20, 45, 400, 40, 25, Paper, FontStyles.Bold);
            distance = Text(top, "", 20, 88, 400, 25, 15, Muted);
            var cr = Rect("Crew", hud.transform, Vector2.one, Vector2.one, new Vector2(-370, -84), new Vector2(-30, -26));
            cr.gameObject.AddComponent<UnityEngine.UI.Image>().color = Ink;
            crew = Text(cr, "", 16, 15, 308, 35, 17, Paper, FontStyles.Bold); crew.alignment = TextAlignmentOptions.Right;
            var bottom = Rect("Winch", hud.transform, Vector2.zero, Vector2.zero, new Vector2(30, 28), new Vector2(440, 128));
            bottom.gameObject.AddComponent<UnityEngine.UI.Image>().color = Ink;
            tensionLabel = Text(bottom, "", 18, 12, 374, 26, 15, Paper, FontStyles.Bold);
            var track = Box("Cable track", bottom, 18, 47, 374, 12, new Color(.24f, .31f, .32f));
            var fill = Rect("Cable tension", track, Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero);
            tension = fill.gameObject.AddComponent<UnityEngine.UI.Image>(); tension.color = Amber;
            Text(bottom, "E  HOOK     Q  WINCH     R  RESET", 18, 73, 374, 25, 13, Muted, FontStyles.Bold);
            var speedRect = Rect("Speed", hud.transform, new Vector2(1, 0), new Vector2(1, 0), new Vector2(-260, 28), new Vector2(-30, 128));
            speedRect.gameObject.AddComponent<UnityEngine.UI.Image>().color = Ink;
            speed = Text(speedRect, "", 12, 8, 206, 65, 46, Paper, FontStyles.Bold); speed.alignment = TextAlignmentOptions.Right;
            Text(speedRect, "KM/H  /  RECOVERY GEAR", 12, 74, 206, 24, 12, Amber, FontStyles.Bold).alignment = TextAlignmentOptions.Right;
            var hintRect = Rect("Driving hints", hud.transform, new Vector2(.5f, 0), new Vector2(.5f, 0), new Vector2(-310, 26), new Vector2(310, 100));
            hint = Text(hintRect, "", 0, 0, 620, 42, 17, Paper, FontStyles.Bold); hint.alignment = TextAlignmentOptions.Center;
            Text(hintRect, "WASD / ARROWS  DRIVE     SPACE  BRAKE     ESC  MENU", 0, 48, 620, 24, 12, Paper).alignment = TextAlignmentOptions.Center;
            marker = Text(hud.transform, "", 0, 0, 280, 50, 17, Amber, FontStyles.Bold); marker.alignment = TextAlignmentOptions.Center;
        }

        private void BuildFinish()
        {
            finish = Screen("Mission Complete").gameObject;
            var panel = Card(finish.transform, "Recovery report", 540, 550);
            Text(panel, "DISPATCH  /  JOB COMPLETE", 36, 36, 468, 30, 16, Amber, FontStyles.Bold);
            Text(panel, "ANOTHER ONE\nBROUGHT HOME.", 32, 95, 480, 140, 43, Paper, FontStyles.Bold);
            result = Text(panel, "", 36, 280, 468, 110, 21, Muted);
            returnLobbyButton = Button(panel, "CREW LOBBY", 36, 414, 468, () => session.Replay(), true);
            Button(panel, "MAIN MENU", 36, 482, 468, () => session.Leave());
        }

        private void BuildPause()
        {
            pause = Screen("Session Menu").gameObject;
            var panel = Card(pause.transform, "Menu", 430, 330);
            Text(panel, "TAKE A BREATHER.", 30, 34, 370, 50, 30, Paper, FontStyles.Bold);
            Text(panel, "Your crew is still on the road.", 30, 98, 370, 50, 18, Muted);
            Button(panel, "BACK TO RECOVERY", 30, 170, 370, () => session.ToggleMenu(), true);
            Button(panel, "LEAVE SESSION", 30, 240, 370, () => session.Leave());
        }

        private void Update()
        {
            bool online = session.Connected && session.LocalSlot >= 0;
            bool inLobby = online && session.World.Phase == RecoveryPhase.Lobby;
            bool complete = online && session.World.Phase == RecoveryPhase.Complete;
            menu.SetActive(!online); lobby.SetActive(inLobby); hud.SetActive(online && !inLobby && !complete);
            finish.SetActive(complete); pause.SetActive(online && session.MenuOpen && !complete);
            if (Time.unscaledTime < nextRefresh) return;
            nextRefresh = Time.unscaledTime + .1f;
            status.text = session.Status;
            if (!online) return;
            var world = session.World; int slot = session.LocalSlot;
            returnLobbyButton.interactable = session.IsHost;
            returnLobbyButton.GetComponentInChildren<TMP_Text>().text = session.IsHost ? "CREW LOBBY" : "WAITING FOR HOST";
            connection.text = session.IsHost ? "HOST SESSION  /  UDP 7777\nInvite a friend using this computer's LAN IP." : "CONNECTED TO HOST  /  FISHNET CO-OP";
            driver0.text = "01   THE GOLDEN OLDIE     " + (world.Ready(0) ? "READY" : "PREPARING");
            driver1.text = world.OccupiedSlot(1) ? "02   THE FOREST RUNNER    " + (world.Ready(1) ? "READY" : "PREPARING") : "02   WAITING FOR A FRIEND...";
            readyLabel.text = world.Ready(slot) ? "NOT READY" : "READY UP";
            readyButton.interactable = !session.MenuOpen;
            deployButton.interactable = session.IsHost && world.CanStart;
            crew.text = "CO-OP  " + world.Occupied + "/2     |     DRIVER 0" + (slot + 1);
            objective.text = world.Phase == RecoveryPhase.HookUp ? "HOOK THE STRANDED CAR" : world.Phase == RecoveryPhase.Recover ? "PULL IT OUT OF THE MUD" : "DELIVER TO THE WORKSHOP";
            float remaining = Vector3.Distance(world.Casualty.transform.position, RecoveryRules.Delivery);
            distance.text = world.Phase == RecoveryPhase.Deliver ? Mathf.RoundToInt(remaining) + " m to the workshop  /  follow the amber flags" : "Rear hitch > front hitch  /  keep your pull smooth";
            speed.text = Mathf.RoundToInt(world.Drivers[slot].Speed * 3.6f).ToString("00");
            float load = world.Tension(slot);
            tension.rectTransform.anchorMax = new Vector2(Mathf.Clamp01(load), 1f);
            tension.color = load > .82f ? new Color(1f, .29f, .13f) : Amber;
            tensionLabel.text = world.Attached(slot) ? "CABLE LOAD   " + Mathf.RoundToInt(load * 100) + "%" : "CABLE   /   DISCONNECTED";
            hint.text = !world.Attached(slot) ? "Get within 14 m, then press E to attach" : load > .82f ? "CABLE OVERLOADED — ease off the throttle" : world.Phase == RecoveryPhase.Deliver ? "Bring the red car into the marked bay and stop" : "Pull gently. Hold Q to reel in the winch.";
            result.text = "RECOVERY TIME    " + System.TimeSpan.FromSeconds(world.Elapsed).ToString(@"mm\:ss") + "\nCABLE BREAKS     " + world.Snaps + "\nCREW REWARD      $" + Mathf.Max(300, 1200 - world.Snaps * 150);
            var goal = world.Phase == RecoveryPhase.Deliver ? RecoveryRules.Delivery + Vector3.up * 4 : world.Casualty.transform.position + Vector3.up * 3.8f;
            var camera = Camera.main;
            if (camera != null)
            {
                Vector3 p = camera.WorldToViewportPoint(goal);
                marker.gameObject.SetActive(p.z > 0 && p.x > .08f && p.x < .92f && p.y > .15f && p.y < .86f);
                marker.rectTransform.anchorMin = marker.rectTransform.anchorMax = new Vector2(p.x, p.y);
                marker.rectTransform.pivot = new Vector2(.5f, 0); marker.rectTransform.anchoredPosition = Vector2.zero;
                marker.text = world.Phase == RecoveryPhase.Deliver ? "WORKSHOP  /  " + Mathf.RoundToInt(remaining) + " m" : "RECOVER THIS CLASSIC";
            }
        }
    }
}
