using System;
using System.Collections.Generic;
using System.IO;
using FishNet.Managing;
using FishNet.Managing.Object;
using FishNet.Object;
using FishNet.Transporting.Tugboat;
using TMPro;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace TowTrouble.Editor
{
    public static class DemoBuilder
    {
        public const string ScenePath = "Assets/TowTrouble/Scenes/CanyonRecovery.unity";
        private const string Root = "Assets/TowTrouble";
        private const string Vendor = "Assets/Low_Poly_Environment_World/Prefabs/";
        private static readonly Dictionary<Material, Material> Converted = new Dictionary<Material, Material>();
        private static Material sand, grass, mud, rock, wood, dark, chrome, rubber, glass, lamp, stripe;
        private static TMP_FontAsset font;
        private static System.Random random;

        [MenuItem("Tow Trouble/Create or Rebuild Demo")]
        public static void CreateDemo()
        {
            if (EditorApplication.isPlaying) throw new InvalidOperationException("Exit Play Mode before rebuilding.");
            var active = UnityEngine.SceneManagement.SceneManager.GetActiveScene();
            if (active.isDirty) throw new InvalidOperationException("Save the current scene before rebuilding the demo.");
            foreach (var dir in new[] { "Scenes", "Art/Materials", "Art/Meshes", "Art/Audio", "Prefabs", "Settings" }) Directory.CreateDirectory(Root + "/" + dir);
            AssetDatabase.Refresh();
            random = new System.Random(6731); Converted.Clear();
            font = LoadFont();
            sand = Mat("Warm sand", new Color(.65f, .43f, .22f));
            grass = Mat("Sage meadow", new Color(.31f, .36f, .13f));
            mud = Mat("Wet mud", new Color(.19f, .115f, .06f), .45f);
            rock = Mat("Sandstone", new Color(.55f, .25f, .12f));
            wood = Mat("Old timber", new Color(.28f, .17f, .075f));
            dark = Mat("Charcoal", new Color(.07f, .085f, .08f), .25f);
            chrome = Mat("Brushed steel", new Color(.53f, .61f, .61f), .7f, .8f);
            rubber = Mat("Tire rubber", new Color(.035f, .042f, .046f), .13f);
            glass = Mat("Blue glass", new Color(.07f, .16f, .19f), .9f, .25f);
            lamp = Mat("Headlamp", new Color(1f, .85f, .45f), .8f);
            lamp.EnableKeyword("_EMISSION"); lamp.SetColor("_EmissionColor", new Color(1f, .72f, .25f) * 1.4f);
            stripe = Mat("Dispatch amber", new Color(1f, .54f, .08f));
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            EditorSceneManager.SaveScene(scene, ScenePath);
            SetupLighting();
            var environment = new GameObject("Canyon County - Environment").transform;
            CreateGround(environment); CreateRiver(environment); DressWorld(environment); CreateWorkshop(environment);
            var vehicles = new RecoveryVehicle[2];
            vehicles[0] = CreateCar("Golden Oldie", new Color(.93f, .72f, .28f), new Vector3(-2.3f, .35f, 30f), false);
            vehicles[1] = CreateCar("Forest Runner", new Color(.27f, .36f, .19f), new Vector3(2.5f, .35f, 30f), false);
            var target = CreateCar("Stranded Classic", new Color(.66f, .18f, .09f), new Vector3(-1f, .12f, 18f), true);
            var networkGo = new GameObject("FishNet - Session Network");
            networkGo.AddComponent<Tugboat>();
            var manager = networkGo.AddComponent<NetworkManager>();
            SetSerialized(manager, "_dontDestroyOnLoad", false);
            var prefabs = AssetDatabase.LoadAssetAtPath<SinglePrefabObjects>(Root + "/Settings/SceneOnlyPrefabs.asset");
            if (prefabs == null) { prefabs = ScriptableObject.CreateInstance<SinglePrefabObjects>(); AssetDatabase.CreateAsset(prefabs, Root + "/Settings/SceneOnlyPrefabs.asset"); }
            manager.SpawnablePrefabs = prefabs;
            var worldGo = new GameObject("Recovery - Server Authority");
            var networkObject = worldGo.AddComponent<NetworkObject>();
            var world = worldGo.AddComponent<RecoveryWorld>();
            var lines = new LineRenderer[2];
            for (int i = 0; i < 2; i++)
            {
                var lineGo = new GameObject("Tow cable " + (i + 1));
                var line = lineGo.AddComponent<LineRenderer>(); line.sharedMaterial = Mat("Cable steel", new Color(.08f, .1f, .11f), .5f, .5f);
                line.positionCount = 18; line.startWidth = line.endWidth = .055f; line.numCapVertices = 4; line.numCornerVertices = 3;
                line.enabled = false; lines[i] = line;
            }
            world.Configure(vehicles, target, lines);
            var cameraGo = new GameObject("Main Camera", typeof(Camera), typeof(AudioListener), typeof(UniversalAdditionalCameraData));
            cameraGo.tag = "MainCamera"; cameraGo.transform.position = new Vector3(15f, 8.7f, 39f);
            cameraGo.transform.LookAt(new Vector3(-1f, 1.1f, 22f));
            var camera = cameraGo.GetComponent<Camera>(); camera.fieldOfView = 57f; camera.farClipPlane = 650f; camera.nearClipPlane = .15f;
            cameraGo.GetComponent<UniversalAdditionalCameraData>().renderPostProcessing = true;
            var rig = cameraGo.AddComponent<RecoveryCamera>();
            var sessionGo = new GameObject("Tow Trouble - Session");
            var session = sessionGo.AddComponent<DemoSession>(); session.Configure(manager, world, rig);
            sessionGo.AddComponent<RecoveryHud>().Configure(session, font);
            networkObject.SetSceneId(9104737621UL);
            EditorUtility.SetDirty(networkObject); EditorUtility.SetDirty(manager);
            PlayerSettings.productName = "Tow Trouble";
            PlayerSettings.companyName = "Canyon County";
            PlayerSettings.runInBackground = true;
            PlayerSettings.defaultScreenWidth = 1600; PlayerSettings.defaultScreenHeight = 900;
            PlayerSettings.fullScreenMode = FullScreenMode.Windowed;
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            EditorSceneManager.MarkSceneDirty(scene); EditorSceneManager.SaveScene(scene);
            AssetDatabase.SaveAssets();
            Selection.activeGameObject = sessionGo;
            SceneView.lastActiveSceneView?.Frame(new Bounds(new Vector3(0, 0, 50), new Vector3(90, 30, 140)), false);
            Debug.Log("[TowTrouble] Demo authored: CanyonRecovery. Press Play to open dispatch.");
        }

        private static TMP_FontAsset LoadFont()
        {
            var existing = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset");
            if (existing != null) return existing;
            TMP_PackageResourceImporter.ImportResources(true, false, false);
            AssetDatabase.Refresh();
            existing = AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/TextMesh Pro/Resources/Fonts & Materials/LiberationSans SDF.asset");
            if (existing == null) throw new InvalidOperationException("TMP essential font did not import.");
            return existing;
        }

        private static void SetupLighting()
        {
            RenderSettings.ambientMode = AmbientMode.Trilight;
            RenderSettings.ambientSkyColor = new Color(.53f, .69f, .84f);
            RenderSettings.ambientEquatorColor = new Color(.59f, .58f, .42f);
            RenderSettings.ambientGroundColor = new Color(.29f, .25f, .18f);
            RenderSettings.fog = true; RenderSettings.fogMode = FogMode.ExponentialSquared;
            RenderSettings.fogDensity = .0037f; RenderSettings.fogColor = new Color(.65f, .76f, .79f);
            var sky = Mat("Canyon sky", Color.white);
            sky.shader = Shader.Find("Skybox/Procedural"); sky.SetColor("_SkyTint", new Color(.39f, .59f, .77f));
            sky.SetFloat("_AtmosphereThickness", .8f); sky.SetFloat("_Exposure", 1.1f); RenderSettings.skybox = sky;
            var light = new GameObject("Late afternoon sun").AddComponent<Light>();
            light.type = LightType.Directional; light.color = new Color(1f, .89f, .7f); light.intensity = 2.1f;
            light.shadows = LightShadows.Soft; light.transform.rotation = Quaternion.Euler(42, -35, 0); RenderSettings.sun = light;
            var volume = new GameObject("Canyon color grade").AddComponent<Volume>(); volume.isGlobal = true;
            string path = Root + "/Settings/CanyonVolume.asset";
            var profile = AssetDatabase.LoadAssetAtPath<VolumeProfile>(path);
            if (profile == null)
            {
                profile = ScriptableObject.CreateInstance<VolumeProfile>(); AssetDatabase.CreateAsset(profile, path);
                var tone = profile.Add<Tonemapping>(true); tone.mode.Override(TonemappingMode.ACES);
                var colors = profile.Add<ColorAdjustments>(true); colors.saturation.Override(8f); colors.contrast.Override(9f); colors.postExposure.Override(.25f);
                var bloom = profile.Add<Bloom>(true); bloom.intensity.Override(.15f); bloom.threshold.Override(1.25f);
                var vignette = profile.Add<Vignette>(true); vignette.intensity.Override(.17f);
                foreach (var component in profile.components) AssetDatabase.AddObjectToAsset(component, profile);
            }
            volume.sharedProfile = profile;
        }

        private static float Height(float x, float z)
        {
            float hills = (Mathf.PerlinNoise(x * .035f + 42f, z * .035f + 13f) - .5f) * 8f;
            float edge = Mathf.SmoothStep(0f, 1f, Mathf.InverseLerp(8f, 35f, Mathf.Abs(x)));
            float h = hills * edge;
            if (z > 48f && z < 64f) h -= Mathf.Sin((z - 48f) / 16f * Mathf.PI) * 2.4f;
            return h;
        }

        private static void CreateGround(Transform parent)
        {
            var vertices = new List<Vector3>(); var uv = new List<Vector2>();
            var triangles = new[] { new List<int>(), new List<int>() };
            for (int z = -70; z < 210; z += 4)
            for (int x = -140; x < 140; x += 4)
            {
                int index = vertices.Count;
                foreach (var v in new[] { new Vector3(x, Height(x, z), z), new Vector3(x, Height(x, z + 4), z + 4), new Vector3(x + 4, Height(x + 4, z + 4), z + 4), new Vector3(x + 4, Height(x + 4, z), z) })
                { vertices.Add(v); uv.Add(new Vector2(v.x * .1f, v.z * .1f)); }
                var list = triangles[Mathf.Abs(x + 2) < 10f ? 0 : 1];
                list.AddRange(new[] { index, index + 1, index + 2, index, index + 2, index + 3 });
            }
            var mesh = new Mesh { name = "Canyon ground", indexFormat = IndexFormat.UInt32 };
            mesh.SetVertices(vertices); mesh.SetUVs(0, uv); mesh.subMeshCount = 2;
            mesh.SetTriangles(triangles[0], 0); mesh.SetTriangles(triangles[1], 1); mesh.RecalculateNormals(); mesh.RecalculateBounds();
            mesh = SaveMesh(mesh, "CanyonGround");
            var go = new GameObject("Sand road and meadow", typeof(MeshFilter), typeof(MeshRenderer), typeof(MeshCollider)); go.layer = 8;
            go.transform.SetParent(parent); go.GetComponent<MeshFilter>().sharedMesh = mesh; go.GetComponent<MeshCollider>().sharedMesh = mesh;
            go.GetComponent<MeshRenderer>().sharedMaterials = new[] { sand, grass };
            Primitive("Mud recovery pit", parent, PrimitiveType.Sphere, new Vector3(0, .015f, 18), new Vector3(14, .14f, 18), mud, false);
            var puddle = Mat("Muddy puddles", new Color(.27f, .2f, .1f), .9f);
            for (int i = 0; i < 20; i++)
            {
                float x = Range(-6f, 6f), z = Range(11, 25);
                Primitive("Mud puddle", parent, PrimitiveType.Sphere, new Vector3(x, -.005f, z), new Vector3(Range(.5f, 2.3f), .014f, Range(.4f, 1.3f)), puddle, false);
            }
            for (int z = 2; z < 127; z += 3)
            {
                if (z > 47 && z < 65) continue;
                foreach (float x in new[] { -3.25f, -1.35f, 1.5f, 3.4f })
                    Primitive("Tire rut", parent, PrimitiveType.Cube, new Vector3(x, Height(x, z) + .01f, z), new Vector3(.17f, .018f, 2.6f), z < 28 ? mud : Mat("Road ruts", new Color(.48f, .31f, .15f)), false);
            }
        }

        private static void CreateRiver(Transform parent)
        {
            var water = Mat("Turquoise river", new Color(.055f, .48f, .53f), .85f, .2f);
            Primitive("Canyon creek", parent, PrimitiveType.Cube, new Vector3(0, -.65f, 56), new Vector3(210, .1f, 12), water, false);
            var foam = Mat("Water glints", new Color(.56f, .86f, .79f), .6f);
            for (int i = 0; i < 105; i++)
            {
                float x = Range(-80, 80); if (Mathf.Abs(x) < 6) continue;
                Primitive("Ripple", parent, PrimitiveType.Cube, new Vector3(x, -.588f, Range(51, 61)), new Vector3(Range(.3f, 2f), .012f, .06f), foam, false);
            }
            for (float z = 47.5f; z < 65; z += .72f)
                Primitive("Bridge plank", parent, PrimitiveType.Cube, new Vector3(0, .08f + Range(-.01f, .01f), z), new Vector3(10.6f, .3f, .67f), wood, true);
            foreach (float x in new[] { -5.3f, 5.3f })
            {
                for (int z = 48; z < 66; z += 4) Primitive("Bridge post", parent, PrimitiveType.Cube, new Vector3(x, .75f, z), new Vector3(.22f, 1.5f, .22f), wood, true);
                Primitive("Bridge rail", parent, PrimitiveType.Cube, new Vector3(x, 1.25f, 56), new Vector3(.18f, .15f, 18), wood, true);
            }
        }

        private static void DressWorld(Transform parent)
        {
            for (int i = 0; i < 95; i++)
            {
                float side = i % 2 == 0 ? -1 : 1; float x = side * Range(19, 105); float z = Range(-35, 180);
                if (z > 48 && z < 64) continue;
                bool canyon = Mathf.Abs(x) > 45 || z < 10;
                string path = canyon ? "Decals/Rocks/prefab_rock_conyon0" + (1 + i % 3) + ".prefab" : "Decals/Rocks/prefab_polytope_rock_large01.prefab";
                PlaceAsset(path, new Vector3(x, Height(x, z) - 1f, z), Range(canyon ? 9f : 2f, canyon ? 23f : 5f), parent, canyon);
            }
            for (int i = 0; i < 165; i++)
            {
                float x = (i % 2 == 0 ? -1 : 1) * Range(12, 95), z = Range(-30, 180);
                if (z > 47 && z < 65) continue;
                string path = z < 23 && i % 3 == 0 ? "Foliage/prefab_tree_cactus.prefab" : "Foliage/prefab_polytope_tree0" + (i % 3 == 0 ? 3 : i % 3 == 1 ? 1 : 4) + ".prefab";
                PlaceAsset(path, new Vector3(x, Height(x, z), z), Range(5.5f, 12f), parent, false);
            }
            for (int i = 0; i < 400; i++)
            {
                float x = Range(-38, 38), z = Range(-15, 145);
                if (Mathf.Abs(x) < 8 || (z > 47 && z < 65)) continue;
                string path = i % 5 == 0 ? "Decals/Rocks/prefab_polytope_rock_small01.prefab" : "Foliage/prefab_polytope_long_grass01.prefab";
                PlaceAsset(path, new Vector3(x, Height(x, z), z), Range(.35f, 1.2f), parent, false);
            }
            for (int z = 35; z < 112; z += 14)
            {
                foreach (float x in new[] { -7.1f, 7.1f })
                {
                    Primitive("Dispatch marker post", parent, PrimitiveType.Cylinder, new Vector3(x, .7f, z), new Vector3(.1f, .7f, .1f), dark, false);
                    Primitive("Amber route flag", parent, PrimitiveType.Cube, new Vector3(x + .35f, 1.2f, z), new Vector3(.7f, .4f, .035f), stripe, false);
                }
            }
            Sign("MUDDY BUSINESS", "RECOVERY SITE  /  01", new Vector3(-8f, 0, 25f), 25, parent);
            Sign("CREEK CROSSING", "SLOW PULLS. STRONG ROPES.", new Vector3(7.5f, 0, 44f), -15, parent);
        }

        private static void CreateWorkshop(Transform parent)
        {
            var red = Mat("Workshop red", new Color(.42f, .12f, .075f));
            Primitive("Workshop", parent, PrimitiveType.Cube, new Vector3(16, 2.7f, 107), new Vector3(13, 5.4f, 16), red, true);
            var roof = Primitive("Workshop roof", parent, PrimitiveType.Cube, new Vector3(16, 5.6f, 107), new Vector3(14, .45f, 18), dark, true);
            roof.transform.rotation = Quaternion.Euler(0, 0, -7);
            Primitive("Garage opening", parent, PrimitiveType.Cube, new Vector3(16, 2.05f, 98.94f), new Vector3(9, 4.1f, .08f), dark, false);
            for (int i = 0; i < 10; i++) Primitive("Door slat", parent, PrimitiveType.Cube, new Vector3(16, .3f + i * .4f, 98.86f), new Vector3(8.8f, .035f, .1f), chrome, false);
            WorldText("CANYON COUNTY", new Vector3(16, 4.75f, 98.65f), Quaternion.identity, 1f, 12, PaperColor(), parent);
            foreach (float x in new[] { -7f, 7f }) Primitive("Delivery boundary", parent, PrimitiveType.Cube, new Vector3(x, .04f, 108), new Vector3(.22f, .08f, 15), stripe, false);
            foreach (float z in new[] { 100.5f, 115.5f }) Primitive("Delivery boundary", parent, PrimitiveType.Cube, new Vector3(0, .04f, z), new Vector3(14, .08f, .22f), stripe, false);
            WorldText("RECOVERY BAY", new Vector3(0, .08f, 107), Quaternion.Euler(90, 0, 0), 1.2f, 12, new Color(1f, .69f, .2f), parent);
            Sign("WELCOME HOME", "CANYON COUNTY RECOVERY", new Vector3(-8, 0, 101), 0, parent);
            foreach (var item in new[] { "prefab_polytope_barrels", "prefab_old_tyre_set", "prefab_wooden_box_open", "prefab_wood_pallet" })
                PlaceAsset("Props/" + item + ".prefab", new Vector3(Range(10, 22), 0, Range(92, 96)), 1.6f, parent, false);
        }

        private static Color PaperColor() => new Color(1f, .88f, .62f);

        private static void Sign(string title, string subtitle, Vector3 position, float angle, Transform parent)
        {
            var sign = new GameObject(title).transform; sign.SetParent(parent); sign.position = position; sign.rotation = Quaternion.Euler(0, angle, 0);
            foreach (float x in new[] { -1.5f, 1.5f }) Primitive("Post", sign, PrimitiveType.Cube, new Vector3(x, 1.2f, 0), new Vector3(.16f, 2.4f, .16f), wood, false);
            Primitive("Board", sign, PrimitiveType.Cube, new Vector3(0, 2f, 0), new Vector3(4.2f, 1.25f, .16f), dark, false);
            var text = WorldText(title + "\n<size=45%>" + subtitle + "</size>", Vector3.zero, Quaternion.identity, .45f, 4f, PaperColor(), sign);
            text.transform.localRotation = Quaternion.identity;
            text.transform.localPosition = new Vector3(0, 2f, -.1f);
        }

        private static TextMeshPro WorldText(string value, Vector3 position, Quaternion rotation, float size, float width, Color color, Transform parent)
        {
            var go = new GameObject(value, typeof(RectTransform), typeof(TextMeshPro)); go.transform.SetParent(parent, false);
            go.transform.position = position; go.transform.rotation = rotation;
            var text = go.GetComponent<TextMeshPro>(); text.font = font; text.text = value; text.fontSize = size * 10; text.color = color;
            text.alignment = TextAlignmentOptions.Center; text.fontStyle = FontStyles.Bold; text.rectTransform.sizeDelta = new Vector2(width, 2f); return text;
        }

        private static GameObject PlaceAsset(string path, Vector3 position, float height, Transform parent, bool sandstone)
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(Vendor + path);
            if (prefab == null) return null;
            var go = (GameObject)PrefabUtility.InstantiatePrefab(prefab, parent);
            var renderers = go.GetComponentsInChildren<Renderer>();
            Bounds bounds = new Bounds(); bool first = true;
            foreach (var r in renderers) { if (first) { bounds = r.bounds; first = false; } else bounds.Encapsulate(r.bounds); }
            float scale = height / Mathf.Max(.1f, bounds.size.y); go.transform.localScale *= scale;
            go.transform.position = position - Vector3.up * bounds.min.y * scale;
            go.transform.rotation = Quaternion.Euler(0, Range(0, 360), 0);
            foreach (var renderer in renderers)
            {
                var materials = renderer.sharedMaterials;
                for (int i = 0; i < materials.Length; i++) materials[i] = sandstone ? rock : ConvertMaterial(materials[i]);
                renderer.sharedMaterials = materials;
            }
            foreach (var collider in go.GetComponentsInChildren<Collider>()) UnityEngine.Object.DestroyImmediate(collider);
            return go;
        }

        private static Material ConvertMaterial(Material source)
        {
            if (source == null) return grass;
            if (Converted.TryGetValue(source, out var known)) return known;
            var material = Mat("Converted_" + source.name, source.HasProperty("_Color") ? source.color : Color.white, .18f);
            if (source.HasProperty("_MainTex")) material.SetTexture("_BaseMap", source.GetTexture("_MainTex"));
            material.SetFloat("_Cull", 0f); Converted.Add(source, material); return material;
        }

        private static RecoveryVehicle CreateCar(string name, Color color, Vector3 position, bool casualty)
        {
            var go = new GameObject(name); go.transform.position = position;
            var paint = Mat(name + " enamel", color, .55f, .2f);
            var trim = Mat(name + " wood trim", new Color(.36f, .15f, .055f), .3f);
            var redLamp = Mat("Tail lamps", new Color(.64f, .025f, .008f), .6f);
            var visual = new GameObject("Coachwork").transform; visual.SetParent(go.transform, false);
            Primitive("Ladder chassis", visual, PrimitiveType.Cube, new Vector3(0, .62f, 0), new Vector3(1.6f, .18f, 4.1f), dark, false);
            RoundedBox("Lower coach", visual, new Vector3(0, 1.03f, -.38f), new Vector3(1.75f, .64f, 2.7f), .14f, paint);
            RoundedBox("Bonnet", visual, new Vector3(0, 1.28f, 1.14f), new Vector3(1.38f, .55f, 1.55f), .15f, paint);
            RoundedBox("Rear trunk", visual, new Vector3(0, 1.27f, -1.47f), new Vector3(1.66f, .58f, .76f), .18f, paint);
            Primitive("Cabin glass", visual, PrimitiveType.Cube, new Vector3(0, 1.94f, -.48f), new Vector3(1.59f, .88f, 1.62f), glass, false);
            RoundedBox("Canvas roof", visual, new Vector3(0, 2.47f, -.48f), new Vector3(1.88f, .18f, 1.97f), .1f, dark);
            foreach (float x in new[] { -.84f, .84f })
            {
                Primitive("Door waistline", visual, PrimitiveType.Cube, new Vector3(x, 1.53f, -.47f), new Vector3(.075f, .1f, 1.88f), trim, false);
                Primitive("Window top rail", visual, PrimitiveType.Cube, new Vector3(x, 2.36f, -.47f), new Vector3(.075f, .1f, 1.88f), trim, false);
                foreach (float z in new[] { -1.34f, -.4f, .37f }) Primitive("Window pillar", visual, PrimitiveType.Cube, new Vector3(x, 1.96f, z), new Vector3(.09f, .9f, .08f), trim, false);
                Primitive("Running board", visual, PrimitiveType.Cube, new Vector3(x * 1.18f, .6f, -.15f), new Vector3(.44f, .12f, 2.2f), dark, false);
                Primitive("Door handle", visual, PrimitiveType.Cube, new Vector3(x * 1.06f, 1.42f, -.62f), new Vector3(.06f, .045f, .21f), chrome, false);
                for (int i = 0; i < 9; i++) Primitive("Bonnet louvre", visual, PrimitiveType.Cube, new Vector3(x * .83f, 1.31f, .65f + i * .12f), new Vector3(.025f, .2f, .035f), dark, false);
                foreach (float z in new[] { -1.35f, 1.3f }) Fender(visual, x * 1.19f, z, paint);
            }
            RoundedBox("Radiator surround", visual, new Vector3(0, 1.17f, 1.98f), new Vector3(.98f, 1.08f, .14f), .16f, chrome);
            Primitive("Radiator black", visual, PrimitiveType.Cube, new Vector3(0, 1.18f, 2.062f), new Vector3(.8f, .83f, .025f), dark, false);
            for (int i = -5; i <= 5; i++) Primitive("Radiator fin", visual, PrimitiveType.Cube, new Vector3(i * .066f, 1.18f, 2.08f), new Vector3(.018f, .83f, .025f), chrome, false);
            foreach (float x in new[] { -.76f, .76f })
            {
                Primitive("Headlamp shell", visual, PrimitiveType.Sphere, new Vector3(x, 1.34f, 1.93f), new Vector3(.4f, .4f, .26f), chrome, false);
                Primitive("Warm headlamp", visual, PrimitiveType.Sphere, new Vector3(x, 1.34f, 2.06f), new Vector3(.31f, .31f, .035f), lamp, false);
                Primitive("Tail lamp", visual, PrimitiveType.Sphere, new Vector3(x, 1.02f, -1.93f), new Vector3(.15f, .15f, .065f), redLamp, false);
            }
            foreach (float z in new[] { -2.03f, 2.16f }) Primitive("Bumper", visual, PrimitiveType.Cube, new Vector3(0, .61f, z), new Vector3(1.99f, .15f, .14f), chrome, false);
            Primitive("Radiator cap", visual, PrimitiveType.Sphere, new Vector3(0, 1.77f, 1.98f), new Vector3(.12f, .1f, .15f), chrome, false);
            var body = go.AddComponent<Rigidbody>(); body.mass = casualty ? 950 : 1350; body.linearDamping = .08f; body.angularDamping = 1.2f;
            body.interpolation = RigidbodyInterpolation.Interpolate; body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
            var collider = go.AddComponent<BoxCollider>(); collider.center = new Vector3(0, 1.22f, 0); collider.size = new Vector3(1.65f, 1.5f, 3.85f);
            var wheels = new WheelCollider[4]; var visuals = new Transform[4];
            for (int i = 0; i < 4; i++)
            {
                float x = i % 2 == 0 ? -.98f : .98f, z = i < 2 ? 1.3f : -1.35f;
                var wheel = new GameObject("Suspension " + i).AddComponent<WheelCollider>(); wheel.transform.SetParent(go.transform, false); wheel.transform.localPosition = new Vector3(x, .57f, z);
                wheel.radius = .47f; wheel.mass = 28; wheel.suspensionDistance = .23f;
                var spring = wheel.suspensionSpring; spring.spring = 37000; spring.damper = 4700; spring.targetPosition = .5f; wheel.suspensionSpring = spring;
                var friction = wheel.forwardFriction; friction.stiffness = 1.65f; wheel.forwardFriction = friction; friction = wheel.sidewaysFriction; friction.stiffness = 1.8f; wheel.sidewaysFriction = friction;
                wheels[i] = wheel;
                var v = new GameObject("Wheel " + i).transform; v.SetParent(go.transform, false); v.localPosition = wheel.transform.localPosition; visuals[i] = v;
                var tire = Primitive("Tire", v, PrimitiveType.Cylinder, Vector3.zero, new Vector3(.94f, .18f, .94f), rubber, false); tire.transform.localRotation = Quaternion.Euler(0, 0, 90);
                var rim = Primitive("Painted wheel disc", v, PrimitiveType.Cylinder, new Vector3(Mathf.Sign(x) * .19f, 0, 0), new Vector3(.61f, .015f, .61f), paint, false); rim.transform.localRotation = Quaternion.Euler(0, 0, 90);
                Primitive("Hub cap", v, PrimitiveType.Sphere, new Vector3(Mathf.Sign(x) * .22f, 0, 0), new Vector3(.11f, .24f, .24f), chrome, false);
                for (int j = 0; j < 20; j++)
                {
                    float angle = j * Mathf.PI * 2 / 20;
                    var tread = Primitive("Tread", v, PrimitiveType.Cube, new Vector3(0, Mathf.Sin(angle) * .467f, Mathf.Cos(angle) * .467f), new Vector3(.34f, .045f, .055f), rubber, false);
                    tread.transform.localRotation = Quaternion.Euler(-j * 18, 0, 0);
                }
            }
            var front = new GameObject("Front tow eye").transform; front.SetParent(go.transform, false); front.localPosition = new Vector3(0, .66f, 2.25f);
            var rear = new GameObject("Rear tow eye").transform; rear.SetParent(go.transform, false); rear.localPosition = new Vector3(0, .66f, -2.15f);
            foreach (var hitch in new[] { front, rear }) Primitive("Tow eye", hitch, PrimitiveType.Sphere, Vector3.zero, new Vector3(.15f, .15f, .18f), chrome, false);
            var controller = go.AddComponent<RecoveryVehicle>(); controller.Configure(wheels, visuals, front, rear, casualty);
            var audio = go.AddComponent<AudioSource>(); audio.clip = EngineClip(); audio.loop = true; audio.playOnAwake = true; audio.spatialBlend = .8f; audio.minDistance = 3; audio.maxDistance = 45; audio.volume = .12f;
            AddDust(go.transform);
            var prefabPath = Root + "/Prefabs/" + name.Replace(" ", "") + ".prefab";
            PrefabUtility.SaveAsPrefabAssetAndConnect(go, prefabPath, InteractionMode.AutomatedAction);
            return controller;
        }

        private static void Fender(Transform parent, float x, float z, Material material)
        {
            var vertices = new List<Vector3>(); var triangles = new List<int>();
            for (int i = 0; i <= 16; i++)
            {
                float angle = Mathf.Lerp(-.2f, Mathf.PI + .2f, i / 16f);
                foreach (float side in new[] { -.25f, .25f }) vertices.Add(new Vector3(side, .57f + Mathf.Sin(angle) * .62f, Mathf.Cos(angle) * .62f));
                if (i > 0) { int k = i * 2; triangles.AddRange(new[] { k - 2, k - 1, k, k - 1, k + 1, k }); }
            }
            var mesh = new Mesh { name = "Swept fender" }; mesh.SetVertices(vertices); mesh.SetTriangles(triangles, 0); mesh.RecalculateNormals();
            mesh = SaveMesh(mesh, "Fender");
            var go = new GameObject("Swept fender", typeof(MeshFilter), typeof(MeshRenderer)); go.transform.SetParent(parent, false);
            go.transform.localPosition = new Vector3(x, 0f, z);
            go.GetComponent<MeshFilter>().sharedMesh = mesh; go.GetComponent<MeshRenderer>().sharedMaterial = material;
        }

        private static void RoundedBox(string name, Transform parent, Vector3 center, Vector3 size, float bevel, Material material)
        {
            // An eight-sided section softens the coachwork without a runtime mesh dependency.
            var vertices = new List<Vector3>();
            var section = new[] { new Vector2(-size.x/2+bevel, -size.z/2), new Vector2(size.x/2-bevel, -size.z/2), new Vector2(size.x/2, -size.z/2+bevel), new Vector2(size.x/2,size.z/2-bevel), new Vector2(size.x/2-bevel,size.z/2),new Vector2(-size.x/2+bevel,size.z/2),new Vector2(-size.x/2,size.z/2-bevel),new Vector2(-size.x/2,-size.z/2+bevel) };
            foreach (float y in new[] { -size.y/2, size.y/2 }) foreach (var p in section) vertices.Add(new Vector3(p.x, y, p.y));
            var triangles = new List<int>();
            for (int i=0;i<8;i++) { int n=(i+1)%8; triangles.AddRange(new[] { i,n,i+8,n,n+8,i+8 }); }
            for (int i=1;i<7;i++) { triangles.AddRange(new[] {0,i+1,i,8,8+i,9+i}); }
            for (int i=0;i<triangles.Count;i+=3) { int swap=triangles[i+1];triangles[i+1]=triangles[i+2];triangles[i+2]=swap; }
            var mesh = new Mesh { name=name }; mesh.SetVertices(vertices); mesh.SetTriangles(triangles,0); mesh.RecalculateNormals();
            mesh = SaveMesh(mesh, name.Replace(" ",""));
            var go=new GameObject(name,typeof(MeshFilter),typeof(MeshRenderer));go.transform.SetParent(parent,false);go.transform.localPosition=center;
            go.GetComponent<MeshFilter>().sharedMesh=mesh;go.GetComponent<MeshRenderer>().sharedMaterial=material;
        }

        private static AudioClip EngineClip()
        {
            string path = Root + "/Art/Audio/Engine.wav";
            if (!File.Exists(path))
            {
                const int rate=22050, count=22050; using var stream=new FileStream(path,FileMode.Create);using var writer=new BinaryWriter(stream);
                writer.Write(System.Text.Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+count*2);writer.Write(System.Text.Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(rate);writer.Write(rate*2);writer.Write((short)2);writer.Write((short)16);writer.Write(System.Text.Encoding.ASCII.GetBytes("data"));writer.Write(count*2);
                for(int i=0;i<count;i++){double t=(double)i/rate; double value=Math.Sin(t*70*Math.PI*2)*.45+Math.Sin(t*140*Math.PI*2)*.2+Math.Sin(t*210*Math.PI*2)*.1;writer.Write((short)(value*14000));}
            }
            AssetDatabase.ImportAsset(path); return AssetDatabase.LoadAssetAtPath<AudioClip>(path);
        }

        private static void AddDust(Transform parent)
        {
            var go = new GameObject("Road dust");go.transform.SetParent(parent,false);go.transform.localPosition=new Vector3(0,.35f,-1.8f);
            var particle=go.AddComponent<ParticleSystem>(); var main=particle.main;main.startLifetime=1f;main.startSpeed=.5f;main.startSize=.3f;main.startColor=new Color(.65f,.47f,.25f,.2f);main.maxParticles=60;main.simulationSpace=ParticleSystemSimulationSpace.World;
            var emission=particle.emission;emission.rateOverTime=0;var shape=particle.shape;shape.shapeType=ParticleSystemShapeType.Box;shape.scale=new Vector3(1.7f,.1f,.2f);
            var color=particle.colorOverLifetime;color.enabled=true;var gradient=new Gradient();gradient.SetKeys(new[]{new GradientColorKey(new Color(.68f,.47f,.24f),0)},new[]{new GradientAlphaKey(.18f,0),new GradientAlphaKey(0,1)});color.color=gradient;
            var size=particle.sizeOverLifetime;size.enabled=true;size.size=new ParticleSystem.MinMaxCurve(1f,AnimationCurve.Linear(0,.3f,1,2));
            var material=Mat("Dust particles",new Color(.7f,.5f,.26f,.15f));material.shader=Shader.Find("Universal Render Pipeline/Particles/Unlit");material.SetFloat("_Surface",1);material.SetFloat("_Blend",0);material.SetFloat("_SrcBlend",(float)BlendMode.SrcAlpha);material.SetFloat("_DstBlend",(float)BlendMode.OneMinusSrcAlpha);material.SetFloat("_ZWrite",0);material.renderQueue=3000;
            go.GetComponent<ParticleSystemRenderer>().sharedMaterial=material;
        }

        private static Material Mat(string name, Color color, float smoothness=.12f, float metallic=0f)
        {
            string path=Root+"/Art/Materials/"+name.Replace("/","_")+".mat";
            var material=AssetDatabase.LoadAssetAtPath<Material>(path);
            if(material==null){material=new Material(Shader.Find("Universal Render Pipeline/Lit"));AssetDatabase.CreateAsset(material,path);}
            material.SetColor("_BaseColor",color);material.SetFloat("_Smoothness",smoothness);material.SetFloat("_Metallic",metallic);material.enableInstancing=true;EditorUtility.SetDirty(material);return material;
        }

        private static Mesh SaveMesh(Mesh mesh,string name)
        {
            string path=Root+"/Art/Meshes/"+name+".asset";var known=AssetDatabase.LoadAssetAtPath<Mesh>(path);
            if(known!=null){EditorUtility.CopySerialized(mesh,known);UnityEngine.Object.DestroyImmediate(mesh);return known;}
            AssetDatabase.CreateAsset(mesh,path);return mesh;
        }

        private static GameObject Primitive(string name,Transform parent,PrimitiveType type,Vector3 position,Vector3 scale,Material material,bool collision)
        {
            var go=GameObject.CreatePrimitive(type);go.name=name;go.transform.SetParent(parent,false);go.transform.localPosition=position;go.transform.localScale=scale;go.GetComponent<Renderer>().sharedMaterial=material;
            if(!collision)UnityEngine.Object.DestroyImmediate(go.GetComponent<Collider>());else go.layer=8;
            return go;
        }

        private static float Range(float min,float max)=>min+(float)random.NextDouble()*(max-min);
        private static void SetSerialized(UnityEngine.Object target,string property,bool value){var so=new SerializedObject(target);var p=so.FindProperty(property);if(p!=null){p.boolValue=value;so.ApplyModifiedPropertiesWithoutUndo();}}
    }
}
